import time
import datetime
import sys
import os
import random
import requests
import flask
from flask import Flask,request,render_template,redirect
import enroller_constants

enrolldata = {
    "membername": "Robbie",
    "address":"123 Queen St E",
    "city":"Toronto",
    "prov":"ON",
    "gender":"M",
    "ramq":"",
    "applyfor":"Member Only",
    "spousename": "",
    "spousecovered":"",
    "spouseprovider":"",
    "spouseplannum":""
}

app = flask.Flask(__name__)

def send_request(url,body):
    print(url,body)
    try:
        req = requests.post(url=url,json=body,auth=(enroller_constants.ADS_UID, enroller_constants.ADS_PWD),verify=False)
    except Exception as error:
        print(error)

    return req

def update_enroll_data(form_data):
    for k,v in form_data.items():
        enrolldata[k] = v
    return True

def goto_step(currentStep,action):
    goto = ''
    body = {
        "action": action,
        "province": enrolldata['prov'],
        "applicants": enrolldata['applyfor'],
        "currentstep": currentStep,
        "spousecovered": enrolldata['spousecovered']
    }

    req = send_request(enroller_constants.ADS_GOTO_URL,body)
    if req:
        goto = req.text.strip("\"")
    else:
        print("Request failed")
    return goto

def get_form_fields(step):

    fields=[]

    if step == "memberinfo":
        fields.append({"key":"membername","label":"Member Full Name","list":"","min":"3","max":"30","placeholder":"First and last name...","type":"Text"})
        fields.append({"key":"address","label":"Address","list":"","min":"4","max":"40","placeholder":"Street address...","type":"Text"})
        fields.append({"key":"city","label":"City","list":"","min":"2","max":"30","placeholder":"City or town...","type":"Text"})
        fields.append({"key":"prov","label":"Province","list":"provinces","min":"2","max":"2","placeholder":"","type":"list"})
        fields.append({"key":"gender","label":"Gender","list":"genders","min":"1","max":"1","placeholder":"","type":"list"})
    elif step == "ramq":
        fields.append({"key":"ramq","label":"Member enrolled in RAMQ?","list":"yesno","min":"1","max":"1","placeholder":"","type":"list"})
    elif step == "applyingfor":
        fields.append({"key":"applyfor","label":"Who are you applying for?","list":"applicants","min":"1","max":"30","placeholder":"none","type":"list"})
    elif step == "spouseinfo":
        fields.append({"key":"spousename","label":"Spouse Full Name","list":"none","min":"5","max":"30","placeholder":"Enter full name","type":"Text"})
        fields.append({"key":"spousecovered","label":"Is spouse covered under another plan?","list":"yesno","min":"1","max":"1","placeholder":"none","type":"list"})
    elif step == "spouseplan":
        fields.append({"key":"spouseprovider","label":"Spouse's plan provider name","list":"none","min":"5","max":"20","placeholder":"Enter provider name...","type":"Text"})
        fields.append({"key":"spouseplannumr","label":"Spouse's plan number","list":"none","min":"5","max":"20","placeholder":"Enter plan number...","type":"Text"})
    elif step == "summary":
        fields.append({"key":"membername","label":"Member Full Name","list":"","min":"3","max":"30","placeholder":"First and last name...","type":"Text"})
        fields.append({"key":"address","label":"Address","list":"","min":"4","max":"40","placeholder":"Street address...","type":"Text"})
        fields.append({"key":"city","label":"City","list":"","min":"2","max":"30","placeholder":"City or town...","type":"Text"})
        fields.append({"key":"prov","label":"Province","list":"provinces","min":"2","max":"2","placeholder":"","type":"list"})
        fields.append({"key":"gender","label":"Gender","list":"genders","min":"1","max":"1","placeholder":"","type":"list"})
        fields.append({"key":"ramq","label":"Member enrolled in RAMQ?","list":"yesno","min":"1","max":"1","placeholder":"","type":"list"})
    else:
        fields.append({"key":"membername","label":"Member Full Name","list":"","min":"3","max":"30","placeholder":"First and last name...","type":"Text"})
        fields.append({"key":"address","label":"Address","list":"","min":"4","max":"40","placeholder":"Street address...","type":"Text"})
    return fields

def get_step_layout(step):
    layout = ''
    body = {
        "step": step
    }

    req = send_request(enroller_constants.ADS_STEP_BUILDER_URL,body)
    if req:
        layout = req.json()
    else:
        return {
                 "headertext":"Page Being Built",
                 "instructions":"Come back soon for exciting stuff!",
                 "hasquestions":"false",
                 "nextbutton":"true",
                 "prevbutton":"true"
             }

    return layout

# basic
@app.route('/')
def home():
    return "Hello World!"

@app.route('/enrollments/<step>',methods=['post', 'get'])
def form_step(step):
    goto = step
    update_enroll_data(request.form)
    if request.method == "POST":
        if request.form.get("next"):
            goto = goto_step(step,"next")
        else:
            goto = goto_step(step,"prev")
        return redirect(request.root_url+"enrollments/"+goto)

    sections = get_step_layout(goto)
    if sections["hasquestions"] == "true":
        fields = get_form_fields(goto)
    else:
        fields = []

    return render_template('step.html', step=goto,sections=sections,fields=fields,provinces=enroller_constants.LIST_PROVINCES,genders=enroller_constants.LIST_GENDERS,applicants=enroller_constants.LIST_APPLICANTS,yesno=enroller_constants.LIST_YESNO,enrolldata=enrolldata)

# main
app.run()