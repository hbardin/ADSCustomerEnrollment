#Decision Service Constants
#ADS_GOTO_URL = "https://ads-runtime-cp4ba.dteroks-270004nnp7-31r07-4b4a324f027aea19c5cbc0c3275c4656-0000.mex01.containers.appdomain.cloud/ads/runtime/api/v1/deploymentSpaces/embedded/decisions/decisions%2Fenrollment%2Fenrollmentservice%2FenrollmentServiceDecisionService%2Fv7%2FenrollmentServiceDecisionService-v7.jar/operations/gotostep/execute"
ADS_GOTO_URL = "https://ads-runtime-dtecp4ba.itzroks-6620035ses-l16xyq-4b4a324f027aea19c5cbc0c3275c4656-0000.us-south.containers.appdomain.cloud/ads/runtime/api/v1/deploymentSpaces/embedded/decisions/decisions%2Ftest_decision_automation%2Fenrollmentservice%2FenrollmentServiceDecisionService%2F1%2FenrollmentServiceDecisionService-1.jar/operations/gotostep/execute"
#ADS_STEP_BUILDER_URL = "https://ads-runtime-cp4ba.dteroks-270004nnp7-31r07-4b4a324f027aea19c5cbc0c3275c4656-0000.mex01.containers.appdomain.cloud/ads/runtime/api/v1/deploymentSpaces/embedded/decisions/decisions%2Fenrollment%2Fenrollmentservice%2FenrollmentServiceDecisionService%2Fv7%2FenrollmentServiceDecisionService-v7.jar/operations/stepbuilder/execute"
ADS_STEP_BUILDER_URL = "https://ads-runtime-dtecp4ba.itzroks-6620035ses-l16xyq-4b4a324f027aea19c5cbc0c3275c4656-0000.us-south.containers.appdomain.cloud/ads/runtime/api/v1/deploymentSpaces/embedded/decisions/decisions%2Ftest_decision_automation%2Fenrollmentservice%2FenrollmentServiceDecisionService%2F1%2FenrollmentServiceDecisionService-1.jar/operations/stepbuilder/execute"
ADS_STEP_METADATA_URL = ""
ADS_UID = "drs"
ADS_PWD = "jwZsTLfieiXYUxKO"


#Choice Lists
LIST_PROVINCES = ["AB","BC","MB","NB","NL","NT","NS","NU","ON","PE","QC","SK","YT"]
LIST_GENDERS = ["F","M","O"]
LIST_APPLICANTS = ["Member Only","Member And Spouse"]
LIST_YESNO = ["Yes","No"]

