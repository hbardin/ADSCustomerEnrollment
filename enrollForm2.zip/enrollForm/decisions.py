import requests

URL = "https://ads-runtime-cp4ba.dteroks-270004nnp7-31r07-4b4a324f027aea19c5cbc0c3275c4656-0000.mex01.containers.appdomain.cloud/ads/runtime/api/v1/deploymentSpaces/embedded/decisions/decisions%2Fenrollment%2Fenrollmentservice%2FenrollmentServiceDecisionService%2Fv5%2FenrollmentServiceDecisionService-v5.jar/operations/gotostep/execute"
uid = "drs"
pwd = "RjcQSNzDTqhlmurl"
body = {
    "action": "prev",
    "province": "AB",
    "applicants": "Member Only",
    "currentstep": "summary",
    "spousecovered": ""
}
req = requests.post(url=URL,json=body,auth=(uid, pwd),verify=False)
print(req.text)